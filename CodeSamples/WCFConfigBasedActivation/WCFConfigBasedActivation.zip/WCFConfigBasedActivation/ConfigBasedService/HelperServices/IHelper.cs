﻿namespace ConfigBasedService.HelperServices
{
    public interface IHelper
    {
        bool IsServiceRunning();
    }
}
